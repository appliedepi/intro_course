# flair 0.0.2

* Added a `NEWS.md` file to track changes to the package.
* Renamed demoR to flair.
* First release.
* Renamed "highlight" to "decorate"
