# basket 0.10.5

* Added a `NEWS.md` file to track changes to the package.
* Made changes for CRAN.
